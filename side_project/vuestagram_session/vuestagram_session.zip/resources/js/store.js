import { createStore } from 'vuex';
import router from './router';

const store = createStore({
    state() {
        return {
            userInfo: localStorage.getItem('userInfo') ? JSON.parse(localStorage.getItem('userInfo')) : null,
        }
    },
    mutations: {
        // 유저 정보 저장
        setUserInfo(state, userInfo) {
            state.userInfo = userInfo;
        },
    },
    actions: {
        /**
         * 로그인 처리
         * 
         * @param {store} context 
         */
        login(context) {
            const url = '/api/login';
            const form = document.querySelector('#loginForm');
            const data = new FormData(form);
            axios.post(url, data)
            .then(response => {
                console.log(response.data); // TODO
                localStorage.setItem('userInfo', JSON.stringify(response.data.data));
                context.commit('setUserInfo', response.data.data);

                router.replace('/board');
            })
            .catch(error => {
                console.log(error.response); // TODO
                alert('로그인에 실패했습니다. (' + error.response.data.code + ')');
            });
        },
    }
});

export default store;
