<template>
  <!-- 상세 -->
  <!-- <div class="board-detail-box">
    <div class="item">
      <img src="">
      <hr>
      <p>내용입니다.</p>
      <hr>
      <div class="etc-box">
        <span>작성자 : 홍길동</span>
        <button class="btn btn-bg-black btn-close">닫기</button>
      </div>
    </div>
  </div> -->

  <!-- 리스트 -->
  <div class="board-list-box">
    <div class="item">
        <img src="/img/cat1.jpg">
    </div>
    <div class="item">
        <img src="/img/cat2.jpg">
    </div>
    <div class="item">
        <img src="/img/cat3.jpg">
    </div>
  </div>

</template>
<script setup>

</script>
<style>
@import url('../css/boardList.css');
</style>
